/*
 * The MIT License
 *
 * Copyright 2013 Pieter Van Eeckhout.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package be.hogent.bulksolvingstatistics.domain;

import be.hogent.bulksolvingstatistics.domain.neuralnetwork.DefaultNeuralNetworkController;
import be.hogent.bulksolvingstatistics.domain.neuralnetwork.DefaultNeuralNetworkRepository;
import be.hogent.bulksolvingstatistics.domain.neuralnetwork.NeuralNetworkController;
import be.hogent.bulksolvingstatistics.domain.neuralnetwork.NeuralNetworkRepository;
import be.hogent.bulksolvingstatistics.domain.neuralnetwork.dataobjects.NeuralNetworkDataObjectBuilder;
import be.hogent.bulksolvingstatistics.domain.neuralnetwork.encogutils.EncogTrainingSet;
import be.hogent.bulksolvingstatistics.persistance.PersistanceController;
import be.hogent.captchabuilder.util.ArrayUtil;
import be.hogent.captchabuilder.util.enums.CaptchaConstants;
import be.hogent.captchasolvingnetwork.network.encog.EncogBasicNetwork;
import be.hogent.captchasolvingnetwork.network.encog.EncogBasicNetworkBuilder;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * DomainFacade.java (UTF-8)
 *
 * Acts as the entrypoint for the domain layer. All calls toward the domain
 * should pass here. Will contain the repositories and the controller instances,
 * if there are any.
 *
 * 2013/05/19
 *
 * @author Pieter Van Eeckhout <vaneeckhout.pieter@gmail.com>
 * @author Pieter Van Eeckhout <pieter.vaneeckhout.q1295@student.hogent.be>
 * @author Hogent StudentID <2000901295>
 * @since 1.0.0
 * @version 1.0.0
 */
public class DomainFacade {

    public NeuralNetworkRepository networkRepository;
    public NeuralNetworkController networkController;
    private NeuralNetworkDataObjectBuilder builder;

    public DomainFacade(PersistanceController persistance) {
        this(persistance, new DefaultNeuralNetworkRepository(), new DefaultNeuralNetworkController());
    }

    public DomainFacade(PersistanceController persistance, NeuralNetworkRepository networkRepository, NeuralNetworkController networkController) {
        this.networkRepository = networkRepository;
        this.networkController = networkController;

        System.out.println("building charset");
        char[] chars = ArrayUtil.concat(CaptchaConstants.LETTERS, CaptchaConstants.NUMBERS, CaptchaConstants.SPECIAL);
        bulkTest(chars, 40, 50);
    }

    private void bulkTest(char[] chars, int hSize, int vSize) {
        System.out.println("creating training input");
        double[][] inputTrainingsSet = EncogTrainingSet.buildTrainingInputSet(chars, hSize, vSize);
        System.out.println("building training ideal");
        double[][] outputTrainingsSet = EncogTrainingSet.buildTrainingIdealSet(chars);


        for (double accuracy = 0.01; accuracy > 0.0001; accuracy -= 0.00005) {
            for (int hiddenLayerSize = 1000; hiddenLayerSize <= 4000; hiddenLayerSize += 1000) {
                int[] hiddenlayers = new int[]{hiddenLayerSize};
                EncogBasicNetwork network = new EncogBasicNetworkBuilder(inputTrainingsSet, outputTrainingsSet)
                        .setHiddenLayers(hiddenlayers)
                        .setAccuracy(accuracy)
                        .createEncogBasicLetterRecognitionNetwork();

                network.buildNetwork();

                long startTimeLong = System.nanoTime();
                network.trainNetwork();
                long endTimeLong = System.nanoTime();
                double durationInSec = (double) ((endTimeLong - startTimeLong) / Math.pow(10, 9));


                builder = new NeuralNetworkDataObjectBuilder();
                builder.setNetworkType("basic")
                        .setLayerLayout(network.getLayerLayout())
                        .setAccuracy(accuracy)
                        .setTrainingDuration(durationInSec)
                        .setIterations(vSize)
                        .setSavedLocation("");
                try {
                    //save the network and set the ID
                   network.setId(PersistanceController.getInstance().addNetwork(builder.createNeuralNetworkDataObject()).getId());
                } catch (SQLException | ClassNotFoundException ex) {
                    Logger.getLogger(DomainFacade.class.getName()).log(Level.SEVERE, null, ex);
                    System.exit(1);
                }

                networkController.setNetwork(network);
                networkController.evaluate(":TEXT!TEXTPRODUCER#ALPHANUMERIC_SPECIAL@MINLENGTH*1@MAXLENGTH*1", 50, 100);
            }
        }
    }
}
