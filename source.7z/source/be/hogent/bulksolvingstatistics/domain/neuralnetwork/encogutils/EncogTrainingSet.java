/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package be.hogent.bulksolvingstatistics.domain.neuralnetwork.encogutils;

import be.hogent.captchabuilder.elementcreator.renderer.text.AbstractWordRenderer;
import be.hogent.captchabuilder.elementcreator.renderer.text.DefaultWordRenderer;
import be.hogent.captchabuilder.elementcreator.renderer.text.WordRenderer;
import be.hogent.captchabuilder.util.ColorRangeRGBA;
import be.hogent.captchabuilder.util.enums.CaptchaConstants;
import be.hogent.captchasolvingnetwork.util.CharacterPatternUtils;
import be.hogent.captchasolvingnetwork.util.ImageToInputPattern;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

/**
 * EncogTrainingSet.java (UTF-8)
 *
 * Utility class to help generate the input and output trainingsets for an encog
 * Neural Network.
 *
 * 2013/05/20
 *
 * @author Pieter Van Eeckhout <vaneeckhout.pieter@gmail.com>
 * @author Pieter Van Eeckhout <pieter.vaneeckhout.q1295@student.hogent.be>
 * @author Hogent StudentID <2000901295>
 * @since 1.0.0
 * @version 1.0.0
 */
public class EncogTrainingSet {

    public static double[][] buildTrainingInputSet(char[] chars, int hSize, int vSize) {
        double[][] inputTrainingsSet = new double[chars.length][];
        System.out.println("building Trainingsets");
        BufferedImage img;
        WordRenderer renderer = new DefaultWordRenderer(new ColorRangeRGBA(0, 0, 0, 255), AbstractWordRenderer.DEFAULT_FONTS, 0, 0.25, CaptchaConstants.DEFAULT_STROKE_WIDTH);
        int index = 0;

        for (char c : chars) {
            img = new BufferedImage(40, 50, BufferedImage.TYPE_INT_ARGB);
            renderer.render(String.valueOf(c), img);

            // check if size == the default size (40*50) if not scale
            if (hSize != 40 || vSize != 50) {
                BufferedImage resized = new BufferedImage(hSize, vSize, img.getType());
                Graphics2D g = resized.createGraphics();
                g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
                g.drawImage(img, 0, 0, hSize, vSize, 0, 0, img.getWidth(), img.getHeight(), null);
                g.dispose();

                //replace the origal with the resized
                img = resized;
            }

            try {
                String path = "TrainingsetImages/";
                // if the directory does not exist, create it and it's parents
                File theDir = new File(path);
                if (!theDir.exists()) {
                    System.out.println("creating directory: " + path);
                    boolean result = theDir.mkdirs();
                    if (result) {
                        System.out.println("Directory created");
                    }
                }

                ImageIO.write(img, "png", new File(path + Character.getName(c) + "-" + hSize + "X" + vSize + ".png"));
            } catch (IOException ex) {
                System.err.println(ex.getMessage());
            }

            inputTrainingsSet[index++] = ImageToInputPattern.colorRangeToDoubleInputPattern(img, 0, 0);
        }

        return inputTrainingsSet;
    }

    public static double[][] buildTrainingIdealSet(char[] chars) {
        double[][] outputTrainingsSet = new double[chars.length][];
        System.out.println("building TrainingIdealSet");
        int index = 0;

        for (char c : chars) {
            outputTrainingsSet[index++] = CharacterPatternUtils.characterToBitArray(c);
        }

        return outputTrainingsSet;
    }
}
