/*
 * The MIT License
 *
 * Copyright 2013 Pieter Van Eeckhout.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package be.hogent.bulksolvingstatistics.domain.neuralnetwork;

import be.hogent.bulksolvingstatistics.domain.neuralnetwork.dataobjects.TestResultDataObjectBuilder;
import be.hogent.bulksolvingstatistics.persistance.PersistanceController;
import be.hogent.captchabuilder.builder.Captcha;
import be.hogent.captchabuilder.builder.CaptchaBuilder;
import be.hogent.captchasolvingnetwork.network.NeuralNetwork;
import be.hogent.captchasolvingnetwork.util.CharacterPatternUtils;
import be.hogent.captchasolvingnetwork.util.ImageToInputPattern;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.sql.SQLException;
import java.util.Arrays;
import org.apache.commons.cli.ParseException;

/**
 * DefaultNeuralNetworkController.java (UTF-8)
 *
 * Default controller implementation.
 *
 * 2013/05/19
 *
 * @author Pieter Van Eeckhout <vaneeckhout.pieter@gmail.com>
 * @author Pieter Van Eeckhout <pieter.vaneeckhout.q1295@student.hogent.be>
 * @author Hogent StudentID <2000901295>
 * @since 1.0.0
 * @version 1.0.0
 */
public class DefaultNeuralNetworkController implements NeuralNetworkController {

    private NeuralNetwork network;
    private TestResultDataObjectBuilder resultBuilder;

    public DefaultNeuralNetworkController() {
    }

    public DefaultNeuralNetworkController(NeuralNetwork network) {
        this();
        this.network = network;
    }

    @Override
    public NeuralNetwork getNetwork() {
        return network;
    }

    @Override
    public void setNetwork(NeuralNetwork network) {
        this.network = network;
    }

    @Override
    public void buildNetwork() {
        network.buildNetwork();
    }

    @Override
    public void trainNetwork() {
        network.trainNetwork();
    }

    @Override
    public double[] evaluate(double[] input, int maxIterations) {
        return network.evaluate(input, maxIterations);
    }

    @Override
    public void evaluate(String captchaBuildString, int amount, int maxIterations) {
        double[] input, result, expectedResult;
        CaptchaBuilder captchaBuilder;
        Captcha captcha;
        char c;
        BufferedImage img;

        for (int i = 0; i < amount; i++) {
            try {
                boolean correct;

                captchaBuilder = new CaptchaBuilder(40, 50, captchaBuildString);
                captcha = captchaBuilder.buildCaptcha();
                c = captcha.getAnswer().charAt(0);
                img = captcha.getImage();

                // check if size == the default size (40*50) if not scale
                if (network.getHsize() != 40 || network.getVsize() != 50) {
                    BufferedImage resized = new BufferedImage(network.getHsize(), network.getVsize(), img.getType());
                    Graphics2D g = resized.createGraphics();
                    g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
                    g.drawImage(img, 0, 0, network.getHsize(), network.getVsize(), 0, 0, img.getWidth(), img.getHeight(), null);
                    g.dispose();

                    //replace the origal with the resized
                    img = resized;
                }

                input = ImageToInputPattern.colorRangeToDoubleInputPattern(img, 0, 0);
                expectedResult = CharacterPatternUtils.characterToBitArray(c);

                long startTimeLong = System.nanoTime();
                result = evaluate(input, maxIterations);
                long endTimeLong = System.nanoTime();
                double durationInSec = (double) ((endTimeLong - startTimeLong) / Math.pow(10, 9));


                System.out.println("Processing output");
                for (int j = 0; j < result.length; j++) {
                    result[j] = (result[j] >= 0.5) ? 1 : 0;
                }

                if (Arrays.equals(result, expectedResult)) {
                    System.out.println(c + " recognized correctly");
                    correct = true;
                } else {
                    System.out.println(c + " recognized Incorrectly");
                    System.err.println("result: " + Arrays.toString(result) + " != " + Arrays.toString(expectedResult));
                    correct = false;
                }

                //create the builder
                resultBuilder = new TestResultDataObjectBuilder();

                //set the network id (should be != -1 if set correctly by saving
                resultBuilder.setNetworkID(network.getId())
                        .setCharacter(c + "")
                        .setTestType(captchaBuildString)
                        .setDuration(durationInSec)
                        .setCorrect(correct);

                PersistanceController.getInstance().addTestResult(resultBuilder.createTestResultDataObject());

            } catch (ParseException | SQLException | ClassNotFoundException ex) {
                System.err.println(ex.getMessage());
            }
        }
    }
}
