/*
 * The MIT License
 *
 * Copyright 2013 Pieter Van Eeckhout.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package be.hogent.bulksolvingstatistics.persistance;

import java.sql.*;

/**
 * DatabaseConnection.java (UTF-8)
 *
 * This class maintains the connection between the application and the SQLite
 * database.
 *
 * 2013/05/20
 *
 * @author Pieter Van Eeckhout <vaneeckhout.pieter@gmail.com>
 * @author Pieter Van Eeckhout <pieter.vaneeckhout.q1295@student.hogent.be>
 * @author Hogent StudentID <2000901295>
 * @since 1.0.0
 * @version 1.0.0
 */
public class DatabaseConnection {

    private final static String JDBC = "org.sqlite.JDBC",
            SQLITEPATH = "jdbc:sqlite:DataBase/BulkStatistics";
    private Connection connection;

    /**
     * Default constructor for DatabaseConnection
     *
     * @throws ClassNotFoundException
     * @throws SQLException
     */
    public DatabaseConnection() throws ClassNotFoundException, SQLException {
        Class.forName(JDBC);
        connection = DriverManager.getConnection(SQLITEPATH);
    }

    /**
     * This method closes the connection between the application and the
     * database. This primary to reduce the memory cost.
     *
     * @throws SQLException
     */
    public void closeConnection() throws SQLException {
        connection.close();
    }

    /**
     * This method return an existing connection. Otherwise it creates a new
     * one.
     *
     * @return
     * @throws SQLException
     * @throws ClassNotFoundException
     */
    public Connection getConnection() throws SQLException, ClassNotFoundException {
        if (connection == null || connection.isClosed()) {
            Class.forName(JDBC);
            connection = DriverManager.getConnection(SQLITEPATH);
        }
        return this.connection;
    }
}