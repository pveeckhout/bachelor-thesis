/*
 * The MIT License
 *
 * Copyright 2013 Pieter Van Eeckhout.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package be.hogent.bulksolvingstatistics.persistance.mappers;

import be.hogent.bulksolvingstatistics.domain.neuralnetwork.dataobjects.NeuralNetworkDataObject;
import be.hogent.bulksolvingstatistics.domain.neuralnetwork.dataobjects.NeuralNetworkDataObjectBuilder;
import be.hogent.bulksolvingstatistics.persistance.PersistanceController;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * NeuralNetworkMapper.java (UTF-8)
 *
 * This class maps NeuralNetworkDataObject to database records.
 *
 * 2013/05/20
 *
 * @author Pieter Van Eeckhout <vaneeckhout.pieter@gmail.com>
 * @author Pieter Van Eeckhout <pieter.vaneeckhout.q1295@student.hogent.be>
 * @author Hogent StudentID <2000901295>
 * @since 1.0.0
 * @version 1.0.0
 */
public class NeuralNetworkMapper implements Mapper<NeuralNetworkDataObject> {

    private final String addStatement = "INSERT INTO networks (type, layout, accuracy, trainingduration, iterations, networksavedlocation) VALUES (?, ?, ?, ?, ?, ?)";
    private final String getStatement = "Select * FROM networks WHERE id=?";
    private final String getAllStatement = "Select * FROM networks";
    private final String updateStatement = "UPDATE networks SET type=?, layout=?, accuracy=?, trainingduration=?, iterations=?, networksavedlocation=? WHERE id=?";
    private final String deleteStatement = "DELETE FROM networks WHERE id=?";
    private PreparedStatement statement;
    private ResultSet resultSet;
    private Connection connection;

    @Override
    public NeuralNetworkDataObject add(NeuralNetworkDataObject object) throws SQLException, ClassNotFoundException {
        try {
            connection = PersistanceController.getInstance().getConnection();
            statement = connection.prepareStatement(addStatement, Statement.RETURN_GENERATED_KEYS);

            statement.setString(1, object.getNetworkType());
            statement.setString(2, object.getLayerLayout());
            statement.setDouble(3, object.getAccuracy());
            statement.setDouble(4, object.getTrainingDuration());
            statement.setInt(5, object.getIterations());
            statement.setString(6, object.getSavedLocation());

            int affectedRows = statement.executeUpdate();
            if (affectedRows == 0) {
                throw new SQLException("Creating network failed, no rows affected.");
            }

            resultSet = statement.getGeneratedKeys();
            if (resultSet.next()) {
                object.setId(resultSet.getInt(1));
            } else {
                throw new SQLException("Creating network failed, no generated key obtained.");
            }

            return object;
        } catch (SQLException | ClassNotFoundException ex) {
            Logger.getLogger(TestResultMapper.class.getName()).log(Level.SEVERE, null, ex);
            throw ex;
        } finally {
            if (resultSet != null) {
                try {
                    resultSet.close();
                } catch (SQLException logOrIgnore) {
                }
            }
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException logOrIgnore) {
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException logOrIgnore) {
                }
            }
        }
    }

    @Override
    public Collection<NeuralNetworkDataObject> findAll() throws ClassNotFoundException, SQLException {
        NeuralNetworkDataObjectBuilder builder;
        List<NeuralNetworkDataObject> coll = new ArrayList<>();
        try {
            statement = PersistanceController.getInstance().getConnection().prepareStatement(getAllStatement);
            resultSet = statement.executeQuery(getAllStatement);

            while (resultSet.next()) {
                builder = new NeuralNetworkDataObjectBuilder();
                builder.setId(resultSet.getInt("id"));
                builder.setNetworkType(resultSet.getString("type"));
                builder.setLayerLayout(resultSet.getString("layout"));
                builder.setAccuracy(resultSet.getDouble("accuracy"));
                builder.setTrainingDuration(resultSet.getDouble("trainingduration"));
                builder.setIterations(resultSet.getInt("iterations"));
                builder.setSavedLocation(resultSet.getString("networksavedlocation"));
            }
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(TestResultMapper.class.getName()).log(Level.SEVERE, null, ex);
            throw ex;
        } finally {
            if (resultSet != null) {
                try {
                    resultSet.close();
                } catch (SQLException logOrIgnore) {
                }
            }
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException logOrIgnore) {
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException logOrIgnore) {
                }
            }
        }

        return coll;
    }

    @Override
    public NeuralNetworkDataObject find(int id) throws ClassNotFoundException, SQLException {
        NeuralNetworkDataObjectBuilder builder;
        try {
            statement = PersistanceController.getInstance().getConnection().prepareStatement(getStatement);

            statement.setInt(1, id);

            resultSet = statement.executeQuery(getStatement);

            while (resultSet.next()) {
                builder = new NeuralNetworkDataObjectBuilder();
                builder.setId(resultSet.getInt("id"));
                builder.setNetworkType(resultSet.getString("type"));
                builder.setLayerLayout(resultSet.getString("layout"));
                builder.setAccuracy(resultSet.getDouble("accuracy"));
                builder.setTrainingDuration(resultSet.getDouble("trainingduration"));
                builder.setIterations(resultSet.getInt("iterations"));
                builder.setSavedLocation(resultSet.getString("networksavedlocation"));
                return builder.createNeuralNetworkDataObject();
            }

            throw new IllegalArgumentException("Network with ID: " + id + " not found");
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(TestResultMapper.class.getName()).log(Level.SEVERE, null, ex);
            throw ex;
        } finally {
            if (resultSet != null) {
                try {
                    resultSet.close();
                } catch (SQLException logOrIgnore) {
                }
            }
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException logOrIgnore) {
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException logOrIgnore) {
                }
            }
        }
    }

    @Override
    public NeuralNetworkDataObject upate(NeuralNetworkDataObject object) throws SQLException, ClassNotFoundException {
        try {
            connection = PersistanceController.getInstance().getConnection();
            statement = connection.prepareStatement(updateStatement);

            statement.setString(1, object.getNetworkType());
            statement.setString(2, object.getLayerLayout());
            statement.setDouble(3, object.getAccuracy());
            statement.setDouble(4, object.getTrainingDuration());
            statement.setInt(5, object.getIterations());
            statement.setString(6, object.getSavedLocation());
            statement.setInt(7, object.getId());

            int affectedRows = statement.executeUpdate();
            if (affectedRows == 0) {
                throw new SQLException("updating network failed, no rows affected.");
            }

            return object;
        } catch (SQLException | ClassNotFoundException ex) {
            Logger.getLogger(TestResultMapper.class.getName()).log(Level.SEVERE, null, ex);
            throw ex;
        } finally {
            if (resultSet != null) {
                try {
                    resultSet.close();
                } catch (SQLException logOrIgnore) {
                }
            }
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException logOrIgnore) {
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException logOrIgnore) {
                }
            }
        }
    }

    @Override
    public void delete(NeuralNetworkDataObject object) throws SQLException, ClassNotFoundException {
        try {
            connection = PersistanceController.getInstance().getConnection();
            statement = connection.prepareStatement(deleteStatement);

            statement.setInt(1, object.getId());

            int affectedRows = statement.executeUpdate();
            if (affectedRows == 0) {
                throw new SQLException("deleting network failed, no rows affected.");
            }

        } catch (SQLException | ClassNotFoundException ex) {
            Logger.getLogger(TestResultMapper.class.getName()).log(Level.SEVERE, null, ex);
            throw ex;
        } finally {
            if (resultSet != null) {
                try {
                    resultSet.close();
                } catch (SQLException logOrIgnore) {
                }
            }
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException logOrIgnore) {
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException logOrIgnore) {
                }
            }
        }
    }
}
