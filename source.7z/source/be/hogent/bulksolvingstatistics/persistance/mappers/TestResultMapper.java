/*
 * The MIT License
 *
 * Copyright 2013 Pieter Van Eeckhout.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package be.hogent.bulksolvingstatistics.persistance.mappers;

import be.hogent.bulksolvingstatistics.domain.neuralnetwork.dataobjects.TestResultDataObject;
import be.hogent.bulksolvingstatistics.domain.neuralnetwork.dataobjects.TestResultDataObjectBuilder;
import be.hogent.bulksolvingstatistics.persistance.PersistanceController;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * DatabaseConnection.java (UTF-8)
 *
 * This class maintains the connection between the application and the SQLite
 * database.
 *
 * 2013/05/20
 *
 * @author Pieter Van Eeckhout <vaneeckhout.pieter@gmail.com>
 * @author Pieter Van Eeckhout <pieter.vaneeckhout.q1295@student.hogent.be>
 * @author Hogent StudentID <2000901295>
 * @since 1.0.0
 * @version 1.0.0
 */
public class TestResultMapper implements Mapper<TestResultDataObject> {

    private final String addStatement = "INSERT INTO tests (network_id, testtype, character, duration, correct) VALUES (?, ?, ?, ?, ?)";
    private final String getStatement = "Select * FROM tests WHERE id=?";
    private final String getAllStatement = "Select * FROM tests";
    private final String updateStatement = "UPDATE tests SET network_id=?, testtype=?, character=?, duration=?, correct=? WHERE id=?";
    private final String deleteStatement = "DELETE FROM tests WHERE id=?";
    private PreparedStatement statement;
    private ResultSet resultSet;
    private Connection connection;

    @Override
    public TestResultDataObject add(TestResultDataObject object) {
        try {
            connection = PersistanceController.getInstance().getConnection();
            statement = connection.prepareStatement(addStatement, Statement.RETURN_GENERATED_KEYS);

            statement.setInt(1, object.getNetworkID());
            statement.setString(2, object.getTestType());
            statement.setString(3, object.getCharacter());
            statement.setDouble(4, object.getDuration());
            statement.setBoolean(5, object.isCorrect());

            int affectedRows = statement.executeUpdate();
            if (affectedRows == 0) {
                throw new SQLException("Creating testrecord failed, no rows affected.");
            }

            resultSet = statement.getGeneratedKeys();
            if (resultSet.next()) {
                object.setId(resultSet.getInt(1));
            } else {
                throw new SQLException("Creating testrecord failed, no generated key obtained.");
            }

            return object;
        } catch (SQLException | ClassNotFoundException ex) {
            Logger.getLogger(TestResultMapper.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (resultSet != null) {
                try {
                    resultSet.close();
                } catch (SQLException logOrIgnore) {
                }
            }
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException logOrIgnore) {
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException logOrIgnore) {
                }
            }
        }

        return null;
    }

    @Override
    public Collection<TestResultDataObject> findAll() throws ClassNotFoundException, SQLException {
        TestResultDataObjectBuilder builder;
        List<TestResultDataObject> coll = new ArrayList<>();
        try {
            statement = PersistanceController.getInstance().getConnection().prepareStatement(getAllStatement);
            resultSet = statement.executeQuery(getAllStatement);

            while (resultSet.next()) {
                builder = new TestResultDataObjectBuilder();
                builder.setID(resultSet.getInt("id"));
                builder.setCharacter(resultSet.getString("character"));
                builder.setCorrect(resultSet.getBoolean("correct"));
                builder.setDuration(resultSet.getDouble("duration"));
                builder.setNetworkID(resultSet.getInt("network_id"));
                builder.setTestType(resultSet.getString("type"));
                coll.add(builder.createTestResultDataObject());
            }
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(TestResultMapper.class.getName()).log(Level.SEVERE, null, ex);
            throw ex;
        } finally {
            if (resultSet != null) {
                try {
                    resultSet.close();
                } catch (SQLException logOrIgnore) {
                }
            }
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException logOrIgnore) {
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException logOrIgnore) {
                }
            }
        }

        return coll;
    }

    @Override
    public TestResultDataObject find(int id) throws ClassNotFoundException, SQLException {
        TestResultDataObjectBuilder builder;
        try {
            statement = PersistanceController.getInstance().getConnection().prepareStatement(getStatement);

            statement.setInt(1, id);

            resultSet = statement.executeQuery(getStatement);

            while (resultSet.next()) {
                builder = new TestResultDataObjectBuilder();
                builder.setID(resultSet.getInt("id"));
                builder.setCharacter(resultSet.getString("character"));
                builder.setCorrect(resultSet.getBoolean("correct"));
                builder.setDuration(resultSet.getDouble("duration"));
                builder.setNetworkID(resultSet.getInt("network_id"));
                builder.setTestType(resultSet.getString("type"));
                return builder.createTestResultDataObject();
            }

            throw new IllegalArgumentException("Test result with ID: " + id + " not found");
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(TestResultMapper.class.getName()).log(Level.SEVERE, null, ex);
            throw ex;
        } finally {
            if (resultSet != null) {
                try {
                    resultSet.close();
                } catch (SQLException logOrIgnore) {
                }
            }
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException logOrIgnore) {
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException logOrIgnore) {
                }
            }
        }
    }

    @Override
    public TestResultDataObject upate(TestResultDataObject object) throws SQLException, ClassNotFoundException {
        try {
            connection = PersistanceController.getInstance().getConnection();
            statement = connection.prepareStatement(updateStatement);

            statement.setInt(1, object.getNetworkID());
            statement.setString(2, object.getTestType());
            statement.setString(3, object.getCharacter());
            statement.setDouble(4, object.getDuration());
            statement.setBoolean(5, object.isCorrect());
            statement.setInt(6, object.getId());

            int affectedRows = statement.executeUpdate();
            if (affectedRows == 0) {
                throw new SQLException("updating testrecord failed, no rows affected.");
            }

            return object;
        } catch (SQLException | ClassNotFoundException ex) {
            Logger.getLogger(TestResultMapper.class.getName()).log(Level.SEVERE, null, ex);
            throw ex;
        } finally {
            if (resultSet != null) {
                try {
                    resultSet.close();
                } catch (SQLException logOrIgnore) {
                }
            }
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException logOrIgnore) {
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException logOrIgnore) {
                }
            }
        }
    }

    @Override
    public void delete(TestResultDataObject object) throws ClassNotFoundException, SQLException {
        try {
            connection = PersistanceController.getInstance().getConnection();
            statement = connection.prepareStatement(deleteStatement);

            statement.setInt(1, object.getId());

            int affectedRows = statement.executeUpdate();
            if (affectedRows == 0) {
                throw new SQLException("deleting testrecord failed, no rows affected.");
            }

        } catch (SQLException | ClassNotFoundException ex) {
            Logger.getLogger(TestResultMapper.class.getName()).log(Level.SEVERE, null, ex);
            throw ex;
        } finally {
            if (resultSet != null) {
                try {
                    resultSet.close();
                } catch (SQLException logOrIgnore) {
                }
            }
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException logOrIgnore) {
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException logOrIgnore) {
                }
            }
        }
    }
}
