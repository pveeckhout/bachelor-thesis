/*
 * The MIT License
 *
 * Copyright 2013 Pieter Van Eeckhout.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package be.hogent.bulksolvingstatistics.persistance;

import be.hogent.bulksolvingstatistics.domain.neuralnetwork.dataobjects.NeuralNetworkDataObject;
import be.hogent.bulksolvingstatistics.domain.neuralnetwork.dataobjects.TestResultDataObject;
import be.hogent.bulksolvingstatistics.persistance.mappers.NeuralNetworkMapper;
import be.hogent.bulksolvingstatistics.persistance.mappers.TestResultMapper;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Collection;

/**
 * PersistanceController.java (UTF-8)
 *
 * Acts as the entrypoint for the persistence layer. All calls toward the
 * Databases should pass here.
 *
 * 2013/05/19
 *
 * @author Pieter Van Eeckhout <vaneeckhout.pieter@gmail.com>
 * @author Pieter Van Eeckhout <pieter.vaneeckhout.q1295@student.hogent.be>
 * @author Hogent StudentID <2000901295>
 * @since 1.0.0
 * @version 1.0.0
 */
public class PersistanceController {

    private static PersistanceController persistanceController;
    private NeuralNetworkMapper networkMapper;
    private TestResultMapper testResultMapper;
    private DatabaseConnection connection;

    /**
     * This method creates a singleton instance of PersistanceController.
     *
     * @return the singleton instance of PersistanceController
     * @throws ClassNotFoundException
     * @throws SQLException
     */
    public static PersistanceController getInstance() throws ClassNotFoundException, SQLException {
        if (persistanceController == null) {
            persistanceController = new PersistanceController();
        }
        return persistanceController;
    }

    private PersistanceController() throws ClassNotFoundException, SQLException {
        connection = new DatabaseConnection();
        networkMapper = new NeuralNetworkMapper();
        testResultMapper = new TestResultMapper();
    }

    /**
     * Passes the CRUB operation to the mapper
     *
     * @param network NeuralNetworkDataObject to be saved
     * @return a NeuralNetworkDataObject containing the data
     * @throws SQLException
     * @throws ClassNotFoundException
     * @see NeuralNetworkMapper
     */
    public NeuralNetworkDataObject addNetwork(NeuralNetworkDataObject network) throws SQLException, ClassNotFoundException {
        return networkMapper.add(network);
    }

    /**
     * Passes the CRUB operation to the mapper
     *
     * @return a Collection holding all the a NeuralNetworkDataObjects in
     * database
     * @throws ClassNotFoundException
     * @throws SQLException
     */
    public Collection<NeuralNetworkDataObject> findAllNetworks() throws ClassNotFoundException, SQLException {
        return networkMapper.findAll();
    }

    /**
     * Passes the CRUB operation to the mapper
     *
     * @param id the id of the NeuralNetworkDataObject to be loaded.
     * @return a NeuralNetworkDataObject containing the data
     * @throws SQLException
     * @throws ClassNotFoundException
     * @see NeuralNetworkMapper
     */
    public NeuralNetworkDataObject findNetwork(int id) throws ClassNotFoundException, SQLException {
        return networkMapper.find(id);
    }

    /**
     * Passes the CRUB operation to the mapper
     *
     * @param network NeuralNetworkDataObject to be updated
     * @return a NeuralNetworkDataObject containing the data
     * @throws SQLException
     * @throws ClassNotFoundException
     * @see NeuralNetworkMapper
     */
    public NeuralNetworkDataObject updateNetwork(NeuralNetworkDataObject network) throws SQLException, ClassNotFoundException {
        return networkMapper.upate(network);
    }

    /**
     * Passes the CRUB operation to the mapper
     *
     * @param network NeuralNetworkDataObject to be removed
     * @throws SQLException
     * @throws ClassNotFoundException
     * @see NeuralNetworkMapper
     */
    public void removeNetwork(NeuralNetworkDataObject network) throws SQLException, ClassNotFoundException {
        networkMapper.delete(network);
    }

    /**
     * Passes the CRUB operation to the mapper
     *
     * @param testResult TestResultDataObject to be saved
     * @return a TestResultDataObject containing the data
     * @throws SQLException
     * @throws ClassNotFoundException
     * @see TestResultMapper
     */
    public TestResultDataObject addTestResult(TestResultDataObject testResult) throws SQLException, ClassNotFoundException {
        return testResultMapper.add(testResult);
    }

    /**
     * Passes the CRUB operation to the mapper
     *
     * @return a Collection holding all the a TestResultDataObject in database
     * @throws SQLException
     * @throws ClassNotFoundException
     * @see TestResultMapper
     */
    public Collection<TestResultDataObject> findAllTestResults() throws ClassNotFoundException, SQLException {
        return testResultMapper.findAll();
    }

    /**
     * Passes the CRUB operation to the mapper
     *
     * @param id the id of the TestResultDataObject to be found
     * @return a TestResultDataObject containing the data
     * @throws SQLException
     * @throws ClassNotFoundException
     * @see TestResultMapper
     */
    public TestResultDataObject findTestResult(int id) throws ClassNotFoundException, SQLException {
        return testResultMapper.find(id);
    }

    /**
     * Passes the CRUB operation to the mapper
     *
     * @param testResult TestResultDataObject to be updated
     * @return a TestResultDataObject containing the data
     * @throws SQLException
     * @throws ClassNotFoundException
     * @see TestResultMapper
     */
    public TestResultDataObject updateTestResult(TestResultDataObject testResult) throws SQLException, ClassNotFoundException {
        return testResultMapper.upate(testResult);
    }

    /**
     * Passes the CRUB operation to the mapper
     *
     * @param testResult TestResultDataObject to be removed
     * @throws SQLException
     * @throws ClassNotFoundException
     * @see TestResultMapper
     */
    public void removeTestResult(TestResultDataObject testResult) throws SQLException, ClassNotFoundException {
        testResultMapper.delete(testResult);
    }

    /**
     * Returns the databaseConnection
     *
     * @return SQlConnection to the database
     * @throws ClassNotFoundException
     * @throws SQLException
     * @see Connection
     */
    public Connection getConnection() throws ClassNotFoundException, SQLException {
        return connection.getConnection();
    }

    /**
     * Closes the database connection.
     *
     * @throws SQLException
     */
    public void closeConnection() throws SQLException {
        connection.closeConnection();
    }
}
