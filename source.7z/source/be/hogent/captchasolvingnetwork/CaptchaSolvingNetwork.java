/*
 * The MIT License
 *
 * Copyright 2013 Pieter Van Eeckhout.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package be.hogent.captchasolvingnetwork;

import be.hogent.bulksolvingstatistics.domain.neuralnetwork.encogutils.EncogTrainingSet;
import be.hogent.captchabuilder.util.ArrayUtil;
import be.hogent.captchabuilder.util.enums.CaptchaConstants;
import be.hogent.captchasolvingnetwork.network.encog.EncogHopfieldNetwork;
import be.hogent.captchasolvingnetwork.network.encog.EncogHopfieldNetworkBuilder;
import java.util.Arrays;
import org.apache.log4j.Logger;

/**
 * CaptchaSolvingNetwork.java (UTF-8)
 *
 * This Is the main startup class for the neural network based captcha solving
 * system. This system will call the captcha-cleanup library and will pass the
 * results of the image cleanup to the neural networks.
 *
 * 2013/04/28
 *
 * @author Pieter Van Eeckhout <vaneeckhout.pieter@gmail.com>
 * @author Pieter Van Eeckhout <pieter.vaneeckhout.q1295@student.hogent.be>
 * @author Hogent StudentID <2000901295>
 * @since 1.0.0
 * @version 1.1.0
 */
public class CaptchaSolvingNetwork {

    private static final Logger logger;

    static {
        logger = Logger.getLogger(CaptchaSolvingNetwork.class);
    }

    public static void main(String[] args) {
        new CaptchaSolvingNetwork();
    }

    public CaptchaSolvingNetwork() {
        this(ArrayUtil.concat(CaptchaConstants.LETTERS, CaptchaConstants.NUMBERS, CaptchaConstants.SPECIAL), 40, 50);
    }

    public CaptchaSolvingNetwork(char[] chars, int hSize, int vSize) {
        chars = new char[] {'a', '5'};
        double[] input, result, expectedResult;
        double[][] inputTrainingsSet = EncogTrainingSet.buildTrainingInputSet(chars, hSize, vSize);
        double[][] outputTrainingsSet = EncogTrainingSet.buildTrainingIdealSet(chars);

 
        System.out.println("creating, building and traing hopfield network");
        EncogHopfieldNetwork hopfield = new EncogHopfieldNetworkBuilder(inputTrainingsSet, hSize, vSize).createEncogHopfieldNetwork();
        hopfield.buildNetwork();
        hopfield.trainNetwork();
        //evaluate over trainingset
        System.out.println("Evaluating hopfield network over trainingset");
        for (int i = 0; i < inputTrainingsSet.length; i++) {
            input = inputTrainingsSet[i];
            expectedResult = outputTrainingsSet[i];
            result = hopfield.evaluate(input, 100);

            if (Arrays.equals(result, expectedResult)) {
                System.out.println(chars[i] + " recognized correctly");
            } else {
                System.out.println(chars[i] + " recognized Incorrectly");
                System.err.println("result: " + Arrays.toString(result) + " != " + Arrays.toString(expectedResult));
            }
        }
    }
}
