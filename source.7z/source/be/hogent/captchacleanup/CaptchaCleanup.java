/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package be.hogent.captchacleanup;

import be.hogent.captchacleanup.utils.textfromimage.GetImageText;
import java.awt.image.BufferedImage;
import java.util.LinkedList;

/**
 *
 * @author Pieter
 */
public class CaptchaCleanup {

    public static BufferedImage drawBoxesAroundText(BufferedImage image) {
        GetImageText myget = new GetImageText(image);
        
        LinkedList boxes = myget.getTextBoxes();
        return myget.isolateText(boxes);
    }
}
