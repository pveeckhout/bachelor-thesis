/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package be.hogent.captchacleanup.utils.textfromimage;

/**
 *
 * @author Pieter
 */
public class TextRegion {
    int x1;
    int y1;
    int x2;
    int y2;
    double mass;

    /**
     * Creates a new <code>TextRegion</code> instance.
     *
     * @param xs an <code>int</code> value
     * @param ys an <code>int</code> value
     * @param xe an <code>int</code> value
     * @param ye an <code>int</code> value
     * @param maxx an <code>int</code> value
     * @param maxy an <code>int</code> value
     */
    TextRegion(int xs, int ys, int xe, int ye, int maxx, int maxy, double m) {
        if (xs < 0)
            x1 = 0;
        else if (xs > maxx)
            x1 = maxx;
        else x1 = xs;
        if (xe < 0)
            x2 = 0;
        else if (xe > maxx)
            x2 = maxx;
        else x2 = xe;
        if (ys < 0)
            y1 = 0;
        else if (ys > maxy)
            y1 = maxy;
        else y1 = ys;
        if (ye < 0)
            y2 = 0;
        else if (ye > maxy)
            y2 = maxy;
        else y2 = ye;
        mass = m;
    }

    int area() {
        return width() * height();
    }

    int height() {
        return y2 - y1;
    }

    int width() {
        return x2 - x1;
    }

    double density() {
        return mass / area();
    }

    double aspect() {
        return (double)height() / (double)width();
    }
}
