/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package be.hogent.captchacleanup.utils;

import java.awt.image.BufferedImage;

/**
 *
 * @author Pieter
 */
public class ImageToArray {

    public static boolean[][] colorRangeToBooleanArray(BufferedImage image, int startRange, int endRange) {
        boolean[][] array = new boolean[image.getWidth()][image.getHeight()];
        int startR = (startRange >> 16) & 0x000000FF;
        int startG = (startRange >> 8) & 0x000000FF;
        int startB = (startRange) & 0x000000FF;
        int endR = (endRange >> 16) & 0x000000FF;
        int endG = (endRange >> 8) & 0x000000FF;
        int endB = (endRange) & 0x000000FF;

        for (int y = 0; y < image.getHeight(); y++) {
            for (int x = 0; x < image.getWidth(); x++) {
                int RGB = image.getRGB(x, y);
                int alpha = (RGB >> 24) & 0x000000FF;
                boolean inRange = false;
                if (alpha != 0) {
                    int R = (startRange >> 16) & 0x000000FF;
                    int G = (startRange >> 8) & 0x000000FF;
                    int B = (startRange) & 0x000000FF;
                    if (startR <= R && R <= endR && startG <= G && G <= endG && startB <= B && B <= endB) {
                        inRange = true;
                    }
                }
                array[x][y] = inRange;
            }

        }

//        // preview array
//        StringBuilder output;
//        for (int y = 0; y < image.getHeight(); y++) {
//            output = new StringBuilder();
//            for (int x = 0; x < image.getWidth(); x++) {
//                if (array[x][y]) {
//                    output.append("#");
//                } else {
//                    output.append(" ");
//                }
//            }
//            System.out.println(output.toString());
//        }

        // return array
        return array;

    }
    
    public static double[][] colorRangeToDoubleArray(BufferedImage image, int startRange, int endRange) {
        double[][] array = new double[image.getWidth()][image.getHeight()];
        int startR = (startRange >> 16) & 0x000000FF;
        int startG = (startRange >> 8) & 0x000000FF;
        int startB = (startRange) & 0x000000FF;
        int endR = (endRange >> 16) & 0x000000FF;
        int endG = (endRange >> 8) & 0x000000FF;
        int endB = (endRange) & 0x000000FF;

        for (int y = 0; y < image.getHeight(); y++) {
            for (int x = 0; x < image.getWidth(); x++) {
                int RGB = image.getRGB(x, y);
                int alpha = (RGB >> 24) & 0x000000FF;
                if (alpha != 0) {
                    int R = (startRange >> 16) & 0x000000FF;
                    int G = (startRange >> 8) & 0x000000FF;
                    int B = (startRange) & 0x000000FF;
                    if (startR <= R && R <= endR && startG <= G && G <= endG && startB <= B && B <= endB) {
                        array[x][y] = 1;
                    } else {
                        array[x][y] = 0;
                    }
                }
            }

        }

//        // preview array
//        StringBuilder output;
//        for (int y = 0; y < image.getHeight(); y++) {
//            output = new StringBuilder();
//            for (int x = 0; x < image.getWidth(); x++) {
//                if (array[x][y]>=1) {
//                    output.append("#");
//                } else {
//                    output.append(" ");
//                }
//            }
//            System.out.println(output.toString());
//        }

        // return array
        return array;
    }
}
